import React from "react";
import NavManagement from "../../molecules/Navigation/NavManagement";

const Navigation = () => {
  return (
    <div>
      <NavManagement />
    </div>
  );
};

export default Navigation;
