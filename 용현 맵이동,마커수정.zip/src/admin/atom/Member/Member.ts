export type Member = {
  member_idx: number;
  member_name: string;
  member_id: string;
  member_email: string;
  member_phone: string;
  member_address: string;
};
