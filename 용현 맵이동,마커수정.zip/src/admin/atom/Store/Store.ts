export type Store = {
  store_id: number;
  store_name: string;
  store_address: string;
  store_phone: string;
};
